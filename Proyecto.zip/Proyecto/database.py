import sqlite3
from crud import crear_conexion

def crear_tablas():
    conn = crear_conexion()
    cursor = conn.cursor()
    
    # Crear tabla de usuarios
    cursor.execute('''CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )''')
    
    # Crear las tablas de tiendas y productos (ya las tienes)
    cursor.execute('''CREATE TABLE IF NOT EXISTS tiendas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT UNIQUE NOT NULL,
        direccion TEXT NOT NULL
    )''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS productos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        precio REAL NOT NULL,
        tienda_id INTEGER,
        FOREIGN KEY (tienda_id) REFERENCES tiendas(id)
    )''')
    
    conn.commit()
    conn.close()

# Llamar a esta función para inicializar la base de datos
crear_tablas()

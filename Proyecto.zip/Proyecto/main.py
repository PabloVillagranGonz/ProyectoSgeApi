from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from database import crear_conexion
from crud import (
    TiendaCreate, TiendaResponse, ProductoCreate, ProductoResponse,
    crear_tienda, create_access_token, get_password_hash, obtener_tiendas, obtener_tienda, crear_producto, obtener_productos, verify_password, verify_token
)
from typing import List

from models import UsuarioCreate, UsuarioResponse

app = FastAPI()

# Definir la dependencia de OAuth2
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# Dependencia para obtener la conexión de la base de datos correctamente
def get_db():
    # Simplemente devolvemos la conexión de la base de datos para usarla en las operaciones
    return crear_conexion()

# Rutas de Tiendas

@app.post("/tiendas/", response_model=TiendaResponse)
def api_crear_tienda(tienda: TiendaCreate, db = Depends(get_db)):
    return crear_tienda(tienda)

@app.get("/tiendas/", response_model=List[TiendaResponse])  # Corrección de tipo de lista
def api_obtener_tiendas(db = Depends(get_db)):
    return obtener_tiendas()

@app.get("/tiendas/{tienda_id}", response_model=TiendaResponse)
def api_obtener_tienda(tienda_id: int, db = Depends(get_db)):
    tienda = obtener_tienda(tienda_id)
    if not tienda:
        raise HTTPException(status_code=404, detail="Tienda no encontrada")
    return tienda

# Rutas de Productos

@app.post("/productos/", response_model=ProductoResponse)
def api_crear_producto(producto: ProductoCreate, db = Depends(get_db)):
    tienda = obtener_tienda(producto.tienda_id)
    if not tienda:
        raise HTTPException(status_code=400, detail="La tienda especificada no existe")
    
    return crear_producto(producto)

@app.get("/productos/", response_model=List[ProductoResponse])  # Corrección de tipo de lista
def api_obtener_productos(db = Depends(get_db)):
    return obtener_productos()


# Función para registrar un nuevo usuario
@app.post("/register", response_model=UsuarioResponse)
async def register(usuario: UsuarioCreate):
    conn = crear_conexion()
    cursor = conn.cursor()

    # Verificar si el nombre de usuario ya está tomado
    cursor.execute("SELECT * FROM usuarios WHERE username = ?", (usuario.username,))
    existing_user = cursor.fetchone()
    if existing_user:
        raise HTTPException(status_code=400, detail="Usuario ya existe")
    
    # Insertar el nuevo usuario con el password hasheado
    hashed_password = get_password_hash(usuario.password)
    cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", 
                   (usuario.username, hashed_password))
    
    conn.commit()
    usuario_id = cursor.lastrowid
    conn.close()

    return UsuarioResponse(id=usuario_id, username=usuario.username)


# Función para obtener el token de acceso cuando el usuario se loguea
@app.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    conn = crear_conexion()
    cursor = conn.cursor()

    # Verificar si el usuario existe
    cursor.execute("SELECT * FROM usuarios WHERE username = ?", (form_data.username,))
    user = cursor.fetchone()
    
    if user is None or not verify_password(form_data.password, user[2]):
        raise HTTPException(status_code=401, detail="Credenciales incorrectas")
    
    # Crear un token de acceso
    access_token = create_access_token(data={"sub": form_data.username})
    conn.close()

    return {"access_token": access_token, "token_type": "bearer"}


# Función para proteger rutas
@app.get("/protected")
async def protected_route(token: str = Depends(oauth2_scheme)):
    # Verificar el token
    user = verify_token(token)
    if user is None:
        raise HTTPException(status_code=401, detail="Token no válido")
    
    return {"message": "Acceso autorizado", "user": user}

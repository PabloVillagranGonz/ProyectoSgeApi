# main.py
from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from database import crear_conexion
from crud import (
    TiendaCreate, TiendaResponse, ProductoCreate, ProductoResponse,
    crear_tienda, eliminar_producto, eliminar_tienda, obtener_tiendas, obtener_tienda,
    crear_producto, obtener_productos, obtener_producto
)
from auth import create_access_token, get_password_hash, verify_password, verify_token
from typing import List
from models import UsuarioCreate, UsuarioResponse

app = FastAPI()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

def get_db():
    return crear_conexion()

# Rutas de Tiendas
@app.post("/tiendas/", response_model=TiendaResponse)
def api_crear_tienda(tienda: TiendaCreate, db=Depends(get_db)):
    return crear_tienda(tienda)

@app.get("/tiendas/", response_model=List[TiendaResponse])
def api_obtener_tiendas(db=Depends(get_db)):
    return obtener_tiendas()

@app.get("/tiendas/{tienda_id}", response_model=TiendaResponse)
def api_obtener_tienda(tienda_id: int, db=Depends(get_db)):
    tienda = obtener_tienda(tienda_id)
    if not tienda:
        raise HTTPException(status_code=404, detail="Tienda no encontrada")
    return tienda

@app.delete("/tiendas/{tienda_id}")
def api_eliminar_tienda(tienda_id: int, db=Depends(get_db)):
    tienda = obtener_tienda(tienda_id)
    if not tienda:
        raise HTTPException(status_code=404, detail="Tienda no encontrada")
    
    eliminar_tienda(tienda_id)
    return {"message": "Tienda eliminada correctamente"}

# Rutas de Productos
@app.post("/productos/", response_model=ProductoResponse)
def api_crear_producto(producto: ProductoCreate, db=Depends(get_db)):
    tienda = obtener_tienda(producto.tienda_id)
    if not tienda:
        raise HTTPException(status_code=400, detail="La tienda especificada no existe")
    
    return crear_producto(producto)

@app.get("/productos/", response_model=List[ProductoResponse])
def api_obtener_productos(db=Depends(get_db)):
    return obtener_productos()

@app.delete("/productos/{producto_id}")
def api_eliminar_producto(producto_id: int, db=Depends(get_db)):
    producto = obtener_producto(producto_id)
    if not producto:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    
    eliminar_producto(producto_id)
    return {"message": "Producto eliminado correctamente"}

# Registro de usuario
@app.post("/register", response_model=UsuarioResponse)
async def register(usuario: UsuarioCreate):
    conn = crear_conexion()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM usuarios WHERE username = ?", (usuario.username,))
    existing_user = cursor.fetchone()
    if existing_user:
        raise HTTPException(status_code=400, detail="Usuario ya existe")
    
    hashed_password = get_password_hash(usuario.password)
    cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", 
                   (usuario.username, hashed_password))
    
    conn.commit()
    usuario_id = cursor.lastrowid
    conn.close()

    return UsuarioResponse(id=usuario_id, username=usuario.username)

# Login
@app.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    conn = crear_conexion()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM usuarios WHERE username = ?", (form_data.username,))
    user = cursor.fetchone()
    
    if user is None or not verify_password(form_data.password, user[2]):
        raise HTTPException(status_code=401, detail="Credenciales incorrectas")
    
    access_token = create_access_token(data={"sub": form_data.username})
    conn.close()

    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/protected")
async def protected_route(token: str = Depends(oauth2_scheme)):
    user = verify_token(token)
    if user is None:
        raise HTTPException(status_code=401, detail="Token no válido")
    
    return {"message": "Acceso autorizado", "user": user}


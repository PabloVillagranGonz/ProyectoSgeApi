from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Float, ForeignKey
from sqlalchemy.orm import relationship
from database import sqlite3
from pydantic import BaseModel
from typing import Optional

# Declaración de Base
Base = declarative_base()


# Esquema de entrada para registrar un usuario
class UsuarioCreate(BaseModel):
    username: str
    password: str

# Esquema de salida para responder con información del usuario
class UsuarioResponse(BaseModel):
    id: int
    username: str

    class Config:
        orm_mode = True


# Modelo de Tienda
class Tienda(Base):
    __tablename__ = "tiendas"
    
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, unique=True, index=True, nullable=False)
    direccion = Column(String, nullable=False)
    productos = relationship("Producto", back_populates="tienda")

# Modelo de Producto
class Producto(Base):
    __tablename__ = "productos"
    
    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    precio = Column(Float, nullable=False)
    tienda_id = Column(Integer, ForeignKey("tiendas.id"))
    
    tienda = relationship("Tienda", back_populates="productos")

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

from crud import *

app = FastAPI()

# Pydantic Models
class TiendaBase(BaseModel):
    nombre: str
    direccion: str

class TiendaResponse(TiendaBase):
    id: int

class ProductoBase(BaseModel):
    nombre: str
    precio: float

class ProductoResponse(ProductoBase):
    id: int
    tienda_id: int


# Rutas para Tiendas
@app.post("/tiendas/", response_model=TiendaResponse)
def api_crear_tienda(tienda: TiendaBase):
    try:
        crear_tienda(tienda.nombre, tienda.direccion)
        return {"id": 1, "nombre": tienda.nombre, "direccion": tienda.direccion}  # Deberías manejar la respuesta para retornar el id generado.
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/tiendas/", response_model=List[TiendaResponse])
def api_obtener_tiendas():
    try:
        tiendas = obtener_tiendas()
        return [{"id": tienda[0], "nombre": tienda[1], "direccion": tienda[2]} for tienda in tiendas]
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/tiendas/{tienda_id}", response_model=TiendaResponse)
def api_obtener_tienda(tienda_id: int):
    try:
        tienda = obtener_tienda(tienda_id)
        if not tienda:
            raise HTTPException(status_code=404, detail="Tienda no encontrada")
        return {"id": tienda[0], "nombre": tienda[1], "direccion": tienda[2]}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# Rutas para Productos
@app.post("/productos/", response_model=ProductoResponse)
def api_crear_producto(producto: ProductoBase):
    try:
        # Validar que la tienda existe
        tienda = obtener_tienda(producto.tienda_id)
        if not tienda:
            raise HTTPException(status_code=400, detail="La tienda especificada no existe")
        
        crear_producto(producto.nombre, producto.precio, producto.tienda_id)
        return {"id": 1, "nombre": producto.nombre, "precio": producto.precio, "tienda_id": producto.tienda_id}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/productos/", response_model=List[ProductoResponse])
def api_obtener_productos():
    try:
        productos = obtener_productos()
        return [{"id": producto[0], "nombre": producto[1], "precio": producto[2], "tienda_id": producto[3]} for producto in productos]
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

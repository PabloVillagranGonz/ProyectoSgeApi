from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

from crud import crear_tienda, obtener_tiendas, obtener_tienda, crear_producto, obtener_productos

app = FastAPI()

class TiendaBase(BaseModel):
    nombre: str
    direccion: str

class TiendaResponse(TiendaBase):
    id: int

class ProductoBase(BaseModel):
    nombre: str
    precio: float
    tienda_id: int 

class ProductoResponse(ProductoBase):
    id: int


# Rutas para Tiendas
@app.post("/tiendas/", response_model=TiendaResponse)
def api_crear_tienda(tienda: TiendaBase):
    tienda_id = crear_tienda(tienda.nombre, tienda.direccion)
    return {"id": tienda_id, "nombre": tienda.nombre, "direccion": tienda.direccion}

@app.get("/tiendas/", response_model=List[TiendaResponse])
def api_obtener_tiendas():
    tiendas = obtener_tiendas()
    return [{"id": tienda[0], "nombre": tienda[1], "direccion": tienda[2]} for tienda in tiendas]

@app.get("/tiendas/{tienda_id}", response_model=TiendaResponse)
def api_obtener_tienda(tienda_id: int):
    tienda = obtener_tienda(tienda_id)
    if not tienda:
        raise HTTPException(status_code=404, detail="Tienda no encontrada")
    return {"id": tienda[0], "nombre": tienda[1], "direccion": tienda[2]}


# Rutas para Productos
@app.post("/productos/", response_model=ProductoResponse)
def api_crear_producto(producto: ProductoBase):
    # Validar que la tienda existe
    tienda = obtener_tienda(producto.tienda_id)
    if not tienda:
        raise HTTPException(status_code=400, detail="La tienda especificada no existe")
    
    producto_id = crear_producto(producto.nombre, producto.precio, producto.tienda_id)
    return {"id": producto_id, "nombre": producto.nombre, "precio": producto.precio, "tienda_id": producto.tienda_id}  

@app.get("/productos/", response_model=List[ProductoResponse])
def api_obtener_productos():
    productos = obtener_productos()
    return [{"id": producto[0], "nombre": producto[1], "precio": producto[2], "tienda_id": producto[3]} for producto in productos]

import sqlite3
from pydantic import BaseModel
from typing import List

class ProductoBase(BaseModel):
    nombre: str
    precio: float

class ProductoCreate(ProductoBase):
    tienda_id: int

class ProductoResponse(ProductoBase):
    id: int
    tienda_id: int

class TiendaBase(BaseModel):
    nombre: str
    direccion: str 

class TiendaCreate(TiendaBase):
    pass

class TiendaResponse(TiendaBase):
    id: int
    productos: List[ProductoResponse] = []

# Conexión a la base de datos
def crear_conexion():
    conn = sqlite3.connect("tiendas.db")
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

# CRUD de Tiendas
def crear_tienda(tienda: TiendaCreate):
    with crear_conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO tiendas (nombre, direccion) VALUES (?, ?)", 
                       (tienda.nombre, tienda.direccion))
        conn.commit()
        tienda_id = cursor.lastrowid
        return TiendaResponse(id=tienda_id, nombre=tienda.nombre, direccion=tienda.direccion)

def obtener_tiendas():
    with crear_conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM tiendas")
        tiendas = cursor.fetchall()
        return [TiendaResponse(id=t[0], nombre=t[1], direccion=t[2]) for t in tiendas]

def obtener_tienda(tienda_id: int):
    with crear_conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM tiendas WHERE id = ?", (tienda_id,))
        tienda = cursor.fetchone()
        if tienda:
            cursor.execute("SELECT * FROM productos WHERE tienda_id = ?", (tienda_id,))
            productos = cursor.fetchall()
            productos_list = [ProductoResponse(id=p[0], nombre=p[1], precio=p[2], tienda_id=p[3]) for p in productos]
            return TiendaResponse(id=tienda[0], nombre=tienda[1], direccion=tienda[2], productos=productos_list)
        return None

def eliminar_tienda(tienda_id: int):
    with crear_conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM tiendas WHERE id = ?", (tienda_id,))
        conn.commit()

# CRUD de Productos
def crear_producto(producto: ProductoCreate):
    with crear_conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO productos (nombre, precio, tienda_id) VALUES (?, ?, ?)",
                       (producto.nombre, producto.precio, producto.tienda_id))
        conn.commit()
        producto_id = cursor.lastrowid
        return ProductoResponse(id=producto_id, nombre=producto.nombre, precio=producto.precio, tienda_id=producto.tienda_id)

def obtener_productos():
    with crear_conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM productos")
        productos = cursor.fetchall()
        return [ProductoResponse(id=p[0], nombre=p[1], precio=p[2], tienda_id=p[3]) for p in productos]

def obtener_producto(producto_id: int):
    with crear_conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM productos WHERE id = ?", (producto_id,))
        producto = cursor.fetchone()
        if producto:
            return ProductoResponse(id=producto[0], nombre=producto[1], precio=producto[2], tienda_id=producto[3])
        return None

def eliminar_producto(producto_id: int):
    with crear_conexion() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM productos WHERE id = ?", (producto_id,))
        conn.commit()

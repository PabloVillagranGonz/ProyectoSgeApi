import sqlite3
from pydantic import BaseModel
from typing import List
from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext

# Definir el secreto para generar el JWT y el algoritmo
SECRET_KEY = "9bd734eaebd4bafae84fb8477e29fcfe7b68aaf5a23c7fcf9bb94101d9c5b7e7"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Configuración para el hashing de contraseñas
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Definir los esquemas con Pydantic

class ProductoBase(BaseModel):
    nombre: str
    precio: float

class ProductoCreate(ProductoBase):
    tienda_id: int

class ProductoResponse(ProductoBase):
    id: int
    tienda_id: int

    class Config:
        from_attributes = True

class TiendaBase(BaseModel):
    nombre: str
    direccion: str 

class TiendaCreate(TiendaBase):
    pass

class TiendaResponse(TiendaBase):
    id: int
    productos: List[ProductoResponse] = []

    class Config:
        from_attributes = True


# Función para conectar a SQLite
def crear_conexion():
    return sqlite3.connect('tiendas.db')


# CRUD de Tiendas

# Crear una tienda
def crear_tienda(tienda: TiendaCreate):
    try:
        with crear_conexion() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO tiendas (nombre, direccion) VALUES (?, ?)", 
                           (tienda.nombre, tienda.direccion))
            conn.commit()
            tienda_id = cursor.lastrowid  # Obtener el ID de la tienda recién creada
            return TiendaResponse(id=tienda_id, nombre=tienda.nombre, direccion=tienda.direccion)
    except sqlite3.Error as e:
        raise Exception(f"Error al crear tienda: {e}")


# Obtener todas las tiendas con productos
def obtener_tiendas():
    try:
        with crear_conexion() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tiendas")
            tiendas = cursor.fetchall()
            
            # Obtener los productos por tienda
            resultado = []
            for tienda in tiendas:
                tienda_id = tienda[0]  # ID de la tienda
                cursor.execute("SELECT * FROM productos WHERE tienda_id = ?", (tienda_id,))
                productos = cursor.fetchall()
                
                productos_res = [ProductoResponse(id=p[0], nombre=p[1], precio=p[2], tienda_id=p[3]) for p in productos]
                
                tienda_res = TiendaResponse(id=tienda_id, nombre=tienda[1], direccion=tienda[2], productos=productos_res)
                resultado.append(tienda_res)

            return resultado
    except sqlite3.Error as e:
        raise Exception(f"Error al obtener tiendas: {e}")


# Obtener una tienda por ID con productos
def obtener_tienda(tienda_id: int):
    try:
        with crear_conexion() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tiendas WHERE id = ?", (tienda_id,))
            tienda = cursor.fetchone()
            
            if tienda:
                cursor.execute("SELECT * FROM productos WHERE tienda_id = ?", (tienda_id,))
                productos = cursor.fetchall()
                
                productos_res = [ProductoResponse(id=p[0], nombre=p[1], precio=p[2], tienda_id=p[3]) for p in productos]
                
                tienda_res = TiendaResponse(id=tienda[0], nombre=tienda[1], direccion=tienda[2], productos=productos_res)
                return tienda_res
            else:
                return None
    except sqlite3.Error as e:
        raise Exception(f"Error al obtener tienda: {e}")


# CRUD de Productos

# Crear un producto
def crear_producto(producto: ProductoCreate):
    try:
        with crear_conexion() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO productos (nombre, precio, tienda_id) VALUES (?, ?, ?)", 
                           (producto.nombre, producto.precio, producto.tienda_id))
            conn.commit()
            producto_id = cursor.lastrowid  # Obtener el ID del producto recién creado
            return ProductoResponse(id=producto_id, nombre=producto.nombre, precio=producto.precio, tienda_id=producto.tienda_id)
    except sqlite3.Error as e:
        raise Exception(f"Error al crear producto: {e}")


# Obtener todos los productos
def obtener_productos():
    try:
        with crear_conexion() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM productos")
            productos = cursor.fetchall()

            return [ProductoResponse(id=p[0], nombre=p[1], precio=p[2], tienda_id=p[3]) for p in productos]
    except sqlite3.Error as e:
        raise Exception(f"Error al obtener productos: {e}")
    

# Función para obtener el hash de una contraseña
def get_password_hash(password: str):
    return pwd_context.hash(password)

# Función para verificar si la contraseña es correcta
def verify_password(plain_password: str, hashed_password: str):
    return pwd_context.verify(plain_password, hashed_password)

# Función para generar un token JWT
def create_access_token(data: dict, expires_delta: timedelta = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)):
    to_encode = data.copy()
    expire = datetime.utcnow() + expires_delta
    to_encode.update({"exp": expire})
    
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Función para decodificar y verificar un token JWT
def verify_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None